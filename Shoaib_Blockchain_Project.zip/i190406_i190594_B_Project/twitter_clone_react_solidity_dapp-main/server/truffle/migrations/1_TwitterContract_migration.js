const TwitterContract = artifacts.require("TwitterContract")

module.exports = function (deployer) {
  deployer.deploy(TwitterContract);
}
